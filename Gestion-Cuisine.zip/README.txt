GENERATEUR DE BON DE COMMANDE - VERSION PORTABLE WINDOWS

ETAPES (UNE SEULE FOIS) :
1) Dezippez ce dossier
2) Double-cliquez sur build_exe.bat
3) Attendez la fin (1 a 3 minutes)

RESULTAT :
Un dossier dist/GenerateurBonCommande contenant :
- GenerateurBonCommande.exe

UTILISATION :
- Copiez ce dossier sur n'importe quel PC Windows 10/11
- Double-cliquez sur l'exe
- L'application s'ouvre dans le navigateur

Aucun Python ou Streamlit requis sur les autres PC.